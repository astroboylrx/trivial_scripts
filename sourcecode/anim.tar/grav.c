#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double xrange=4;
double yrange=4;
double zrange=4;
double step=1;

double drnd48(void)
{
  return drand48()-0.5;
}

int main(void)
{
  int N=400,gone[N];
  double x[N],y[N],z[N],vx[N],vy[N],vz[N],m[N];
  double xh[N],yh[N],zh[N],vxh[N],vyh[N],vzh[N],R[N],drawr[N];
  double rbx[1000],rby[1000],rbz[1000];
  int bloc;
  int i,j,step=0;
  double F,r,t,dt=3e-6;
  double cx,cy,cz,cvx,cvy,cvz;
  double T,U;
  double sum_mass=0;
  double vf=184.5,vxcom,vycom,vzcom;
  double density=250;
  int frameskip=1;
  double rf=1;
  double G=4*M_PI*M_PI;
  srand48(232444);
  for (i=0;i<N-1;i++)
  {
    gone[i]=0;
    m[i]=1;
    x[i]=drnd48()*rf;
    y[i]=drnd48()*rf;
    z[i]=drnd48()*rf;
    vx[i]=vf*y[i];
    vy[i]=vf*(-x[i]);
    vz[i]=drnd48()*vf;
    cx+=x[i]*m[i];
    cy+=y[i]*m[i];
    cz+=z[i]*m[i];
    cvx+=vx[i]*m[i];
    cvy+=vy[i]*m[i];
    cvz+=vz[i]*m[i];
    R[i]=pow(m[i],0.3)/density;
  }
    gone[i]=0;
  m[N-1]=1;
  R[N-1]=pow(m[N-1],0.3)/density;
  x[N-1]=-cx/m[N-1];
  y[N-1]=-cy/m[N-1];
  z[N-1]=-cz/m[N-1];
  vx[N-1]=-cvx/m[N-1];
  vy[N-1]=-cvy/m[N-1];
  vz[N-1]=-cvz/m[N-1];

  for (i=0;i<N;i++){
    gone[i]=0;
    R[i]=pow(m[i],0.3)/density;
    //R[i]=0;
    if (R[i]>0.002) drawr[i]=R[i]; else drawr[i]=0.002;
    cx+=x[i]*m[i];
    cy+=y[i]*m[i];
    cz+=z[i]*m[i];
    cvx+=vx[i]*m[i];
    cvy+=vy[i]*m[i];
    cvz+=vz[i]*m[i];
    sum_mass+=m[i];
  }
  cvx/=sum_mass;
  cvy/=sum_mass;
  cvz/=sum_mass;
  cx/=sum_mass;
  cy/=sum_mass;
  cz/=sum_mass;

  for (i=0;i<N;i++){
    x[i]-=cx;
    y[i]-=cy;
    z[i]-=cz;
    vx[i]-=cvx;
    vy[i]-=cvy;
    vz[i]-=cvz;
  }
  printf("!start main loop\n");

  for (t=0;1;t+=dt)
  {
//    frameskip=200000/(N*N)+1;
    frameskip=10;
    if (step % frameskip == 0)
    {
      printf("C 0 1 0\n");
      rbx[bloc]=(x[0]);
      rby[bloc]=(y[0]);
      rbz[bloc]=(z[0]);
      for (j=bloc;j<bloc+(1000-1);j++)
      {
        printf("C 0 %e 0\n",(1000-(j-bloc))/(double)1000);
        printf("l3 %e %e %e %e %e %e\n",rbx[j%1000],rby[j%1000],rbz[j%1000],rbx[(j+1)%1000],rby[(j+1)%1000],rbz[(j+1)%1000]);
      }
      bloc=(bloc+(1000-1))%1000;







    printf("C 0.2 0.2 0.5\n");
          double ii;
   for (i=0;i<N;i++)
      {
//        vx[i]-=vxcom/(N*5);
//        vy[i]-=vycom/(N*5);
//        vz[i]-=vzcom/(N*5);
        printf("C 0.5 0.0 0.0\n");
        printf("l3 %e %e %e %e %e 0\n",x[i],y[i],z[i],x[i],y[i],0);
        printf("C 1 1 1\n");
        printf("c3 %e %e %e %e\n",x[i],y[i],z[i],R[i]);
      }
      printf("C 1 1 1\nT -0.9 -0.9\nt=%.3f, %d frames (skip %d)    E=%.8e     T=%.8e      U=%.8e         Planets %d     Ring buffer %d\n",t,step,frameskip,T+U,T,U,N,bloc);
      printf("F\n");
    }

    if (step % 1 == 0)
    {
      for (i=0;i<N;i++)
      {
        for (j=i+1;j<N;j++)
        {
          r=sqrt( (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) +(z[i]-z[j])*(z[i]-z[j]) );
          if (r<R[i]+R[j])
          {
            x[i]=(x[i]*m[i]+x[j]*m[j])/(m[i]+m[j]);
            y[i]=(y[i]*m[i]+y[j]*m[j])/(m[i]+m[j]);
            z[i]=(z[i]*m[i]+z[j]*m[j])/(m[i]+m[j]);
            vx[i]=(vx[i]*m[i]+vx[j]*m[j])/(m[i]+m[j]);
            vy[i]=(vy[i]*m[i]+vy[j]*m[j])/(m[i]+m[j]);
            vz[i]=(vz[i]*m[i]+vz[j]*m[j])/(m[i]+m[j]);
            m[i]=m[i]+m[j];
            R[i]=pow(R[i]*R[i]*R[i]+R[j]*R[j]*R[j],1./3.);
            x[j]=x[N-1];
            y[j]=y[N-1];
            z[j]=z[N-1];
            vx[j]=vx[N-1];
            vy[j]=vy[N-1];
            vz[j]=vz[N-1];
            R[j]=R[N-1];
            m[j]=m[N-1];
            printf("!Merger of planets %d and %d\n",i,j);
            N=N-1;
          }
        }
      }
    }
   double Uhere,There;
  step++;
    for (i=0;i<N;i++) 
    {
      vxh[i]=vx[i];
      vyh[i]=vy[i];
      vzh[i]=vz[i];
    }

    U=T=0;

    for (i=0;i<N;i++)
    {
      Uhere=There=0;
      for (j=i+1;j<N;j++)
      {
        if (gone[j]) 
        {
//          printf("!planet %d is gone, ignoring its effect\n",j);
          continue;
        }
        r=sqrt( (x[i]-x[j])*(x[i]-x[j]) + (y[i]-y[j])*(y[i]-y[j]) +(z[i]-z[j])*(z[i]-z[j]) );
        F=G*m[i]*m[j]/(r*r*r)*dt/2;
        vxh[i] += -F * (x[i]-x[j])/m[i];
        vxh[j] -= -F * (x[i]-x[j])/m[j];
        vyh[i] += -F * (y[i]-y[j])/m[i];
        vyh[j] -= -F * (y[i]-y[j])/m[j];
        vzh[i] += -F * (z[i]-z[j])/m[i];
        vzh[j] -= -F * (z[i]-z[j])/m[j];
        Uhere -= G*m[i]*m[j]/r;
      }
      There += 0.5*m[i]*(vx[i]*vx[i]+vy[i]*vy[i]+vz[i]*vz[i]);
      xh[i] = x[i]+vx[i]*dt/2;
      yh[i] = y[i]+vy[i]*dt/2;
      zh[i] = z[i]+vz[i]*dt/2;
      if (r>20 && Uhere+There > 0)
      {
         x[i]=x[N-1];
         y[i]=y[N-1];
         z[j]=z[N-1];
         vx[i]=vx[N-1];
         vy[i]=vy[N-1];
         vz[i]=vz[N-1];
         R[i]=R[N-1];
         m[i]=m[N-1];
         N--;
         printf("!Planet %d escaped (total energy %e, radius %e)\n",i,Uhere+There,r);
      }
    U+=Uhere;
    T+=There;
    }
    vxcom=vycom=vzcom=0;
    for (i=0;i<N;i++)
    {
      if (gone[i]) continue;
      for (j=i+1;j<N;j++)
      {
        if (gone[j]) continue;
        r=sqrt( (xh[i]-xh[j])*(xh[i]-xh[j]) + (yh[i]-yh[j])*(yh[i]-yh[j]) +(zh[i]-zh[j])*(zh[i]-zh[j]) );
        F=G*m[i]*m[j]/(r*r*r)*dt;
        vx[i] += -F * (xh[i]-xh[j])/m[i];
        vx[j] -= -F * (xh[i]-xh[j])/m[j];
        vy[i] += -F * (yh[i]-yh[j])/m[i];
        vy[j] -= -F * (yh[i]-yh[j])/m[j];
        vz[i] += -F * (zh[i]-zh[j])/m[i];
        vz[j] -= -F * (zh[i]-zh[j])/m[j];
      }
      x[i] = x[i]+vxh[i]*dt;
      y[i] = y[i]+vyh[i]*dt;
      z[i] = z[i]+vzh[i]*dt;
      vxcom += vx[i]*m[i];
      vycom += vy[i]*m[i];
      vzcom += vz[i]*m[i];
    }
      printf("C 0.3 0.3 0.6\n");
 }
}
