#include <stdio.h>
#include <math.h>

int draw_skip=10;
int trail_update_skip = 4;
#define max_trail 8000 // do it with #define so damn array thingie won't complain
#define trail_len 4000
int trail_count = -1;
double trail_step=1.25;
double dt = 0.005; // timestep
double sigma = 10;
double beta = 8./3.;
double rho = 28;

double fx(double x, double y, double z)
{
  return sigma * (y-x);
}

double fy(double x, double y, double z)
{
  return x * (rho - z) - y;
}

double fz(double x, double y, double z)
{
  return x * y - beta * z;
}



double hypot3(double a, double b, double c)
{
  return sqrt(a*a+b*b+c*c);
}
    
// Do animation stuff using "anim" library
void draw(double x, double y, double z)
{
  int i,j,a1,a2;
  static int drawct=0;
  double tone;
  static double sumx, sumy, sumz, avgx=0, avgy=0, avgz=0;
  static double cx[max_trail];  
  static double cy[max_trail];  
  static double cz[max_trail]; 
  if (trail_count == -1) // we've not been here before, zero arrays
  {
    for (i=0;i<trail_count;i++)
    {
      cx[i]=x; cy[i]=y; cz[i]=z;
    }
    trail_count=0;
  }

  drawct++;
//  if (drawct % trail_update_skip == 0)
  if (hypot3(x-cx[trail_count],y-cy[trail_count],z-cz[trail_count]) > trail_step)
  {
    trail_count = (trail_count + 1) % max_trail;
    cx[trail_count] = x;
    cy[trail_count] = y;
    cz[trail_count] = z;
  }
  sumx=sumy=sumz=0;
  if (drawct % draw_skip == 0)
  {
  for (i=2;i<max_trail;i++)
  {
    tone = (double)i/max_trail;
    tone = 1-( (1-tone) * max_trail/trail_len);
    if (i>max_trail-trail_len) printf("C %e %e %e\n",tone,tone,tone+0.2);
    a1=(i+trail_count)%max_trail;
    a2=(i+trail_count+max_trail-1)%max_trail;
   if (i>max_trail-trail_len)  printf("l3 %e %e %e %e %e %e\n",cx[a1]-avgx,cy[a1]-avgy,cz[a1]-avgz,cx[a2]-avgx,cy[a2]-avgy,cz[a2]-avgz);
    sumx += cx[a1];
    sumy += cy[a1];
    sumz += cz[a1];
  }
  printf("C 1 1 10\n");
  printf("c3 %e %e %e 1\n",x-avgx,y-avgy,z-avgz);
  avgx=0*sumx/(max_trail-2);
  avgy=0*sumy/(max_trail-2);
  avgz=0*sumz/(max_trail-2);
  printf("F\n");
  }
}



int main(void)
{
  double x, y, z, sx1, sx2, sx3, sx4, sy1, sy2, sy3, sy4, sz1, sz2, sz3, sz4, t=0;
  double x2, y2, z2, x3, y3, z3, x4, y4, z4, sxf, syf, szf;
  int steps;
  x=y=z=1;
 
  printf("S3 50 150\n"); // set up scale factor for the animation thingie
 
  while (1==1)
  {
    steps++;
    t += dt;
    
    // Start RK4
    sx1 = fx(x,y,z);
    sy1 = fy(x,y,z);
    sz1 = fz(x,y,z);
 
    x2 = x + sx1 * dt * 0.5;
    y2 = y + sy1 * dt * 0.5;
    z2 = z + sz1 * dt * 0.5;
    sx2 = fx(x2,y2,z2);
    sy2 = fy(x2,y2,z2);
    sz2 = fz(x2,y2,z2);
 
    x3 = x + sx2 * dt * 0.5;
    y3 = y + sy2 * dt * 0.5;
    z3 = z + sz2 * dt * 0.5;
    sx3 = fx(x3,y3,z3);
    sy3 = fy(x3,y3,z3);
    sz3 = fz(x3,y3,z3);

    x4 = x + sx3 * dt;
    y4 = y + sy3 * dt;
    z4 = z + sz3 * dt;
    sx4 = fx(x4,y4,z4);
    sy4 = fy(x4,y4,z4);
    sz4 = fz(x4,y4,z4);
    
    sxf = 1./6. * (sx1 + sx2*2 + sx3*2 + sx4);
    syf = 1./6. * (sy1 + sy2*2 + sy3*2 + sy4);
    szf = 1./6. * (sz1 + sz2*2 + sz3*2 + sz4);
    
    x += sxf * dt;
    y += syf * dt;
    z += szf * dt;
    
    
    // Only draw every ndraw timesteps
    draw(x,y,z);
  }
}
